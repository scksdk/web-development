Check out it's working here: https://ch210.csb.app/!#

# BBC
Created with CodeSandbox\
App to list
 ***Breaking Bad Characters &amp; their Quotes***\
\
A web app(using ReactJS) that has

1. listing of all the breaking bad characters 
    1. list shows name, occupation, date of birth & status of the character.
    2. A list can have pagination, one page should have 10 characters.
    3. one should be able to apply category based filters on the list (optional).
    4. one should be able to search the name of any character in the list (optional).

2. page for details of the characters 
    1. This gives the following information about character
        1. Name & Image of the character
        2. Date of Birth
        3. Occupation
        4. Status (dead or alive)
        5. Nickname (if present)
        6. Actor who portrays the character
        7. Seasons in which the character appears
        8. All quotes by the character

APIs used to build the app - [https://breakingbadapi.com/documentation](https://breakingbadapi.com/documentation)
